A cat & mouse game. [literally]

Ever felt like you were hearding cats?

Playable [here](http://www.nuclearcarrot.co.uk/html5/cat-and-mouse/)

This game started as a way for me to learn html5.

All images are from [gettyicons](http://www.gettyicons.com/free-icon) or [all-free-download](http://all-free-download.com/free-vector/vector-clip-art/)


